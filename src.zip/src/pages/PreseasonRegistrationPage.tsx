import { useEffect, useMemo, useState } from 'react';
import { CheckCircle2 } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';

import RegistrationHeroCard from '../components/RegistrationHeroCard';
import TeamLogoGrid from '../components/TeamLogoGrid';
import { resolveGamerTag } from '../lib/gamerTag';
import { getTeamAssets } from '../lib/teamAssets';
import { useAuth } from '../state/auth/AuthProvider';
import { requireSupabaseClient } from '../lib/supabaseClient';
import '../styles/preseason-registration.css';

const supabase = requireSupabaseClient();
const TEAMS_CACHE_KEY = 'eg:preseason:teams:v2';
const TEAMS_CACHE_TTL_MS = 10 * 60 * 1000;

const REG_UNLOCK_AT =
  import.meta.env.VITE_REG_UNLOCK_AT?.trim() || '2026-03-05T17:30:00+11:00'; // 5:30pm Melbourne (AEDT)
const PRESEASON_FORMAT_NOTE = 'Format: 2 home-and-away matches, followed by knockout finals.';
const AFL26_LOGO_URL = 'https://zohtixrgskbzosgfluni.supabase.co/storage/v1/object/public/Assets/afl26-logo.png';

type TeamRow = {
  id: string;
  name: string;
  displayName: string;
  logo_url?: string | null;
  slug?: string | null;
};

type TeamFetchRow = {
  id: string | null;
  name: string | null;
  short_name?: string | null;
  shortName?: string | null;
  short_label?: string | null;
  shortLabel?: string | null;
  nickname?: string | null;
  logo_url?: string | null;
  slug?: string | null;
};

type ProfileRow = {
  display_name?: string | null;
  psn?: string | null;
  xbox_gamertag?: string | null;
};

type AuthMetaUser = {
  psn?: string | null;
  user_metadata?: Record<string, unknown> | null;
} | null;

type RegistrationRow = {
  user_id: string;
  season_slug?: string | null;
  coach_name?: string | null;
  psn_name?: string | null;
  psn?: string | null;
  coach_display_name?: string | null;
  coach_psn?: string | null;
  pref_team_names?: string | string[] | null;
  preferences?: unknown;
  pref_team_ids?: string[] | null;
  pref_team_1?: string | null;
  pref_team_2?: string | null;
  pref_team_3?: string | null;
  pref_team_4?: string | null;
};

type PrettyRegistrationSummary = {
  coachDisplayName: string;
  coachPsn: string;
  prefTeamNames: string;
};

const AFL_CANONICAL_KEYS = [
  'adelaide',
  'brisbane',
  'carlton',
  'collingwood',
  'essendon',
  'fremantle',
  'geelong',
  'goldcoast',
  'gws',
  'hawthorn',
  'melbourne',
  'northmelbourne',
  'portadelaide',
  'richmond',
  'stkilda',
  'sydney',
  'westcoast',
  'westernbulldogs',
] as const;

type CanonicalKey = (typeof AFL_CANONICAL_KEYS)[number];

function text(v: unknown): string {
  return String(v || '').trim();
}

function hasMissingSeasonSlug(error: unknown): boolean {
  const msg = String((error as any)?.message || '').toLowerCase();
  return msg.includes('season_slug') && (msg.includes('column') || msg.includes('does not exist'));
}

function readPrefs(row: RegistrationRow | null): string[] {
  if (!row) return [];

  const direct = row.preferences;
  if (Array.isArray(direct)) {
    const parsed = direct.map((item) => text(item)).filter(Boolean);
    if (parsed.length) return parsed;
  }

  if (typeof direct === 'string') {
    try {
      const parsed = JSON.parse(direct);
      if (Array.isArray(parsed)) {
        const list = parsed.map((item) => text(item)).filter(Boolean);
        if (list.length) return list;
      }
    } catch {
      // ignore malformed string
    }
  }

  if (Array.isArray(row.pref_team_ids) && row.pref_team_ids.length) {
    return row.pref_team_ids.map((id) => text(id)).filter(Boolean);
  }

  return [row.pref_team_1, row.pref_team_2, row.pref_team_3, row.pref_team_4].map((id) => text(id)).filter(Boolean);
}

function assetKeyFromSlugOrName(slug: string, rawName: string): string {
  const s = text(slug).toLowerCase();
  const n = text(rawName).toLowerCase();
  if (s) {
    if (s.includes('port-adelaide')) return 'port adelaide';
    if (s.includes('adelaide')) return 'adelaide';
    if (s.includes('north-melbourne')) return 'north melbourne';
    if (s.includes('melbourne')) return 'melbourne';
    if (s.includes('western-bulldogs') || s.includes('bulldogs')) return 'western bulldogs';
    if (s.includes('gws')) return 'gws';
    if (s.includes('gold-coast')) return 'gold coast';
    if (s.includes('st-kilda')) return 'st kilda';
    if (s.includes('west-coast')) return 'west coast';
    if (s.includes('collingwood')) return 'collingwood';
    if (s.includes('carlton')) return 'carlton';
    if (s.includes('brisbane')) return 'brisbane';
    if (s.includes('fremantle')) return 'fremantle';
    if (s.includes('essendon')) return 'essendon';
    if (s.includes('geelong')) return 'geelong';
    if (s.includes('hawthorn')) return 'hawthorn';
    if (s.includes('richmond')) return 'richmond';
    if (s.includes('sydney')) return 'sydney';
  }
  return n;
}

function canonicalTeamKey(slug: string | null | undefined, name: string | null | undefined): CanonicalKey | '' {
  const s = text(slug).toLowerCase();
  const n = text(name).toLowerCase();
  const combined = `${s} ${n}`;

  if (combined.includes('port-adelaide') || combined.includes('port adelaide')) return 'portadelaide';
  if (combined.includes('north-melbourne') || combined.includes('north melbourne')) return 'northmelbourne';
  if (combined.includes('western-bulldogs') || combined.includes('western bulldogs') || combined.includes('bulldogs')) return 'westernbulldogs';
  if (combined.includes('gold-coast') || combined.includes('gold coast')) return 'goldcoast';
  if (combined.includes('west-coast') || combined.includes('west coast')) return 'westcoast';
  if (combined.includes('st-kilda') || combined.includes('st kilda')) return 'stkilda';
  if (combined.includes('collingwood')) return 'collingwood';
  if (combined.includes('carlton')) return 'carlton';
  if (combined.includes('adelaide')) return 'adelaide';
  if (combined.includes('brisbane')) return 'brisbane';
  if (combined.includes('essendon')) return 'essendon';
  if (combined.includes('fremantle')) return 'fremantle';
  if (combined.includes('geelong')) return 'geelong';
  if (combined.includes('gws') || combined.includes('greater western sydney')) return 'gws';
  if (combined.includes('hawthorn')) return 'hawthorn';
  if (combined.includes('melbourne') && !combined.includes('north')) return 'melbourne';
  if (combined.includes('richmond')) return 'richmond';
  if (combined.includes('sydney')) return 'sydney';
  return '';
}

function normalizeLogoUrl(raw: string | null | undefined, slug: string | null | undefined, rawName: string): string {
  const canonical = canonicalTeamKey(slug, rawName);
  const primaryAssetLogo = text(getTeamAssets(canonical || rawName).logo);
  if (primaryAssetLogo) return primaryAssetLogo;

  const value = text(raw);
  if (value) {
    if (/^https?:\/\//i.test(value)) return value;
    if (value.startsWith('/storage/v1/object/public/')) {
      const base = String(import.meta.env.VITE_SUPABASE_URL || '').replace(/\/$/, '');
      if (base) return `${base}${value}`;
    }

    const cleaned = value.replace(/^\/+/, '').replace(/^public\//, '');
    const asAssetsPath = cleaned.replace(/^assets\//i, '');
    const publicUrl = supabase.storage.from('Assets').getPublicUrl(asAssetsPath).data.publicUrl;
    if (publicUrl) return publicUrl;
  }

  const mapped = getTeamAssets(assetKeyFromSlugOrName(text(slug), rawName)).logo;
  return text(mapped);
}

function shortTeamName(name: string): string {
  const raw = text(name);
  if (!raw) return 'Team';

  const normalized = raw.toLowerCase();
  const exactMap: Record<string, string> = {
    'adelaide crows': 'Adelaide',
    adelaide: 'Adelaide',
    'brisbane lions': 'Brisbane',
    brisbane: 'Brisbane',
    'carlton blues': 'Carlton',
    carlton: 'Carlton',
    collingwood: 'Collingwood',
    'essendon bombers': 'Essendon',
    essendon: 'Essendon',
    fremantle: 'Fremantle',
    geelong: 'Geelong',
    'gold coast suns': 'Gold Coast',
    'gold coast': 'Gold Coast',
    gws: 'GWS',
    'greater western sydney': 'GWS',
    hawthorn: 'Hawthorn',
    melbourne: 'Melbourne',
    'north melbourne': 'North Melbourne',
    port: 'Port Adelaide',
    'port adelaide': 'Port Adelaide',
    richmond: 'Richmond',
    'st kilda': 'St Kilda',
    sydney: 'Sydney',
    westcoast: 'West Coast',
    'west coast': 'West Coast',
    bulldogs: 'Bulldogs',
    'western bulldogs': 'Bulldogs',
  };
  if (exactMap[normalized]) return exactMap[normalized];

  const stripped = raw
    .replace(/\bfootball club\b/gi, '')
    .replace(/\bfc\b/gi, '')
    .replace(/\bthe\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();
  return stripped || raw;
}

function getTeamDisplayName(team: Pick<TeamFetchRow, 'name' | 'short_name' | 'shortName' | 'short_label' | 'shortLabel' | 'nickname'>): string {
  const candidates = [
    text(team.short_name),
    text(team.shortName),
    text(team.short_label),
    text(team.shortLabel),
    text(team.nickname),
    text(team.name),
  ];

  for (const candidate of candidates) {
    if (candidate) return shortTeamName(candidate);
  }

  return 'Team';
}

function dedupeTeams(rows: TeamFetchRow[]): TeamFetchRow[] {
  const byKey = new Map<string, TeamFetchRow>();

  const score = (r: TeamFetchRow) => {
    const hasLogo = Boolean(text(r.logo_url));
    const hasSlug = Boolean(text(r.slug));
    const canonical = canonicalTeamKey(r.slug, r.name);
    const canonicalWeight = canonical ? 1000 : 0;
    const nameLen = text(r.name).length;
    return canonicalWeight + (hasLogo ? 100 : 0) + (hasSlug ? 10 : 0) + Math.min(nameLen, 50);
  };

  rows.forEach((row) => {
    const canonical = canonicalTeamKey(row.slug, row.name);
    const key = canonical || text(row.slug || row.name || row.id).toLowerCase();
    if (!key) return;

    const existing = byKey.get(key);
    if (!existing) {
      byKey.set(key, row);
      return;
    }

    if (score(row) > score(existing)) {
      byKey.set(key, row);
    }
  });

  const ordered = Array.from(byKey.entries()).sort((a, b) => a[0].localeCompare(b[0]));
  return ordered.map((entry) => entry[1]);
}

function seasonSlugCandidates(): string[] {
  return ['preseason-2026', 'preseason'];
}

function mapTeamRows(rows: TeamFetchRow[]): TeamRow[] {
  const deduped = dedupeTeams(rows);
  const mapped = deduped
    .map((team) => {
      const id = text(team.id);
      const rawName = text(team.name);
      if (!id || !rawName) return null;
      return {
        id,
        slug: text(team.slug) || null,
        name: shortTeamName(rawName),
        displayName: getTeamDisplayName(team),
        logo_url: normalizeLogoUrl(team.logo_url || null, team.slug || null, rawName),
      } as TeamRow;
    })
    .filter((team): team is TeamRow => Boolean(team));

  const sourceById = new Map(deduped.map((row) => [text(row.id), row]));
  const canonicalRows = new Map<CanonicalKey, TeamRow>();
  for (const team of mapped) {
    const source = sourceById.get(team.id);
    const canonical = canonicalTeamKey(source?.slug || null, source?.name || team.name);
    if (!canonical) continue;
    if (!canonicalRows.has(canonical)) canonicalRows.set(canonical, team);
  }

  const finalRows = AFL_CANONICAL_KEYS.map((key) => canonicalRows.get(key)).filter((row): row is TeamRow => Boolean(row));
  if (import.meta.env.DEV && finalRows.length !== 18) {
    console.warn(
      '[PreseasonRegistration] Team count not 18 after dedupe:',
      finalRows.length,
      finalRows.map((team) => team.name),
    );
  }
  return finalRows;
}

function readTeamCache(): TeamRow[] | null {
  try {
    const raw = sessionStorage.getItem(TEAMS_CACHE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as { ts?: number; teams?: TeamRow[] };
    if (!parsed?.ts || !Array.isArray(parsed?.teams)) return null;
    if (Date.now() - parsed.ts > TEAMS_CACHE_TTL_MS) return null;
    return parsed.teams;
  } catch {
    return null;
  }
}

function writeTeamCache(nextTeams: TeamRow[]) {
  try {
    sessionStorage.setItem(TEAMS_CACHE_KEY, JSON.stringify({ ts: Date.now(), teams: nextTeams }));
  } catch {
    // ignore cache write failures
  }
}

async function loadProfile(userId: string): Promise<ProfileRow | null> {
  const primaryWithXbox = await supabase
    .from('profiles')
    .select('display_name,psn,xbox_gamertag')
    .eq('user_id', userId)
    .maybeSingle();
  const primary =
    primaryWithXbox.error && String(primaryWithXbox.error.message || '').toLowerCase().includes('xbox_gamertag')
      ? await supabase.from('profiles').select('display_name,psn').eq('user_id', userId).maybeSingle()
      : primaryWithXbox;
  if (!primary.error) return (primary.data || null) as ProfileRow | null;

  const fallbackWithXbox = await supabase
    .from('eg_profiles')
    .select('display_name,psn,xbox_gamertag')
    .eq('user_id', userId)
    .maybeSingle();
  const fallback =
    fallbackWithXbox.error && String(fallbackWithXbox.error.message || '').toLowerCase().includes('xbox_gamertag')
      ? await supabase.from('eg_profiles').select('display_name,psn').eq('user_id', userId).maybeSingle()
      : fallbackWithXbox;
  if (!fallback.error) return (fallback.data || null) as ProfileRow | null;

  throw new Error(primary.error.message || fallback.error.message || 'Unable to load profile.');
}

async function loadRegistrationFromTable(userId: string): Promise<RegistrationRow | null> {
  for (const slug of seasonSlugCandidates()) {
    const scoped = await supabase
      .from('eg_preseason_registrations')
      .select('*')
      .eq('user_id', userId)
      .eq('season_slug', slug)
      .maybeSingle();

    if (!scoped.error) return (scoped.data || null) as RegistrationRow | null;
    if (!hasMissingSeasonSlug(scoped.error)) continue;
  }

  const fallback = await supabase.from('eg_preseason_registrations').select('*').eq('user_id', userId).maybeSingle();
  if (!fallback.error) return (fallback.data || null) as RegistrationRow | null;

  return null;
}

async function loadPrettyRegistration(userId: string): Promise<RegistrationRow | null> {
  for (const slug of seasonSlugCandidates()) {
    const scoped = await supabase
      .from('eg_preseason_registrations_pretty')
      .select('*')
      .eq('user_id', userId)
      .eq('season_slug', slug)
      .maybeSingle();

    if (!scoped.error) return (scoped.data || null) as RegistrationRow | null;
    if (!hasMissingSeasonSlug(scoped.error)) continue;
  }

  const fallbackByUser = await supabase
    .from('eg_preseason_registrations_pretty')
    .select('*')
    .eq('user_id', userId)
    .maybeSingle();

  if (!fallbackByUser.error) return (fallbackByUser.data || null) as RegistrationRow | null;
  return null;
}

async function saveProfileFlag(userId: string, nowIso: string) {
  const payload = { preseason_registered: true, updated_at: nowIso };
  const primary = await supabase.from('profiles').update(payload).eq('user_id', userId);
  if (!primary.error) return;
  await supabase.from('eg_profiles').update(payload).eq('user_id', userId);
}

async function resolvePreseasonSeasonId(): Promise<string | null> {
  const exact = await supabase.from('eg_seasons').select('id').eq('slug', 'preseason-2026').maybeSingle();
  if (!exact.error && exact.data?.id) return String(exact.data.id);

  const fallback = await supabase.from('eg_seasons').select('id').eq('slug', 'preseason').maybeSingle();
  if (!fallback.error && fallback.data?.id) return String(fallback.data.id);

  return null;
}

async function insertRegistration(args: {
  userId: string;
  selectedTeamIds: string[];
  coachName: string;
  coachPsn: string;
  prefTeamNames: string[];
  prefTeamSlugs: string[];
}) {
  const seasonId = await resolvePreseasonSeasonId();

  const payload = {
    user_id: args.userId,
    coach_name: args.coachName,
    psn: args.coachPsn,
    psn_name: args.coachPsn,
    pref_team_ids: args.selectedTeamIds,
    pref_team_1: args.selectedTeamIds[0] ?? null,
    pref_team_2: args.selectedTeamIds[1] ?? null,
    pref_team_3: args.selectedTeamIds[2] ?? null,
    pref_team_4: args.selectedTeamIds[3] ?? null,
    pref_team_names: args.prefTeamNames,
    pref_team_slugs: args.prefTeamSlugs,
    season_id: seasonId,
    season_slug: 'preseason-2026',
  };

  const inserted = await supabase.from('eg_preseason_registrations').insert(payload);
  if (!inserted.error) return;

  const duplicate = String(inserted.error.message || '').toLowerCase();
  if (duplicate.includes('duplicate key') || duplicate.includes('unique')) {
    throw new Error('You are already registered for preseason.');
  }

  throw new Error(inserted.error.message || 'Unable to save registration.');
}

function formatPrefNames(value: unknown): string {
  if (Array.isArray(value)) {
    return value.map((v) => text(v)).filter(Boolean).join(', ');
  }
  return text(value);
}

function getRemainingMs(): number {
  const openAtMs = new Date(REG_UNLOCK_AT).getTime();
  return Math.max(0, openAtMs - Date.now());
}

function formatCountdown(remainingMs: number): string {
  const totalSeconds = Math.floor(Math.max(0, remainingMs) / 1000);
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
}

export default function PreseasonRegistrationPage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, loading: authLoading } = useAuth();
  const isLoggedIn = Boolean(user?.id);
  const isRegistrationRoute =
    location.pathname === '/preseason-registration' || location.pathname === '/preseason/register';

  const [teamsLoading, setTeamsLoading] = useState(true);
  const [profileLoading, setProfileLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [fatalError, setFatalError] = useState<string | null>(null);
  const [inlineError, setInlineError] = useState<string | null>(null);

  const [teams, setTeams] = useState<TeamRow[]>([]);
  const [profile, setProfile] = useState<ProfileRow | null>(null);
  const [authMetaUser, setAuthMetaUser] = useState<AuthMetaUser>(null);
  const [selectedTeamIds, setSelectedTeamIds] = useState<string[]>([]);
  const [submitted, setSubmitted] = useState(false);
  const [submittedSummary, setSubmittedSummary] = useState<PrettyRegistrationSummary | null>(null);
  const [profileLoadError, setProfileLoadError] = useState<string | null>(null);
  const [isOpen, setIsOpen] = useState(getRemainingMs() <= 0);
  const [countdown, setCountdown] = useState(formatCountdown(getRemainingMs()));
  const lockActive = isRegistrationRoute && !isOpen;

  useEffect(() => {
    const tick = () => {
      const remaining = getRemainingMs();
      setIsOpen(remaining <= 0);
      setCountdown(formatCountdown(remaining));
    };

    tick();
    const timer = window.setInterval(tick, 1000);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    let alive = true;

    const cached = readTeamCache();
    if (cached?.length) {
      setTeams(cached);
      setTeamsLoading(false);
    } else {
      setTeamsLoading(true);
    }

    (async () => {
      try {
        const teamsRes = await supabase.from('eg_teams').select('id,name,short_name,logo_url,slug').order('name', { ascending: true });
        if (!alive) return;
        if (teamsRes.error) throw new Error(teamsRes.error.message || 'Unable to load teams.');

        const finalRows = mapTeamRows((teamsRes.data || []) as TeamFetchRow[]);
        setTeams(finalRows);
        writeTeamCache(finalRows);
      } catch (error: any) {
        console.error('[EG CRASH] PreseasonRegistration team load failed', error);
        if (!alive) return;
        if (!cached?.length) {
          setFatalError(String(error?.message || 'Unable to load registration page.'));
        }
      } finally {
        if (alive) setTeamsLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, []);

  useEffect(() => {
    if (authLoading) return;

    let alive = true;
    setFatalError(null);

    if (!user?.id) {
      setProfileLoading(false);
      setProfile(null);
      setAuthMetaUser(null);
      setSubmitted(false);
      setSubmittedSummary(null);
      setProfileLoadError(null);
      return () => {
        alive = false;
      };
    }

    setProfileLoading(true);
    (async () => {
      try {
        const [profileRes, regRes, prettyRes, authUserRes] = await Promise.all([
          loadProfile(user.id),
          loadRegistrationFromTable(user.id),
          loadPrettyRegistration(user.id),
          supabase.auth.getUser(),
        ]);

        if (!alive) return;

        setProfile(profileRes);
        setAuthMetaUser((authUserRes.data?.user as unknown as AuthMetaUser) || null);

        if (profileRes) {
          setProfileLoadError(null);
        } else {
          console.warn('[PreseasonRegistration] profile row missing, using auth metadata fallback for user', user.id);
          setProfileLoadError('Profile sync pending. Using account metadata for now.');
        }

        const existingPrefs = readPrefs((regRes || null) as RegistrationRow | null).slice(0, 4);
        if (existingPrefs.length) {
          setSelectedTeamIds(existingPrefs);
          setSubmitted(true);
        }

        if (prettyRes) {
          setSubmittedSummary({
            coachDisplayName: text(prettyRes.coach_display_name) || text(profileRes?.display_name) || '',
            coachPsn: text(prettyRes.coach_psn) || text(profileRes?.psn) || '',
            prefTeamNames: formatPrefNames(prettyRes.pref_team_names),
          });
        }
      } catch (error: any) {
        console.error('[EG CRASH] PreseasonRegistration profile/registration load failed', error);
        if (!alive) return;
        setFatalError(String(error?.message || 'Unable to load registration page.'));
      } finally {
        if (alive) setProfileLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, [authLoading, user?.id]);

  const signedInName = useMemo(() => {
    const display = text(profile?.display_name);
    if (display) return display;
    const metaDisplay = text(authMetaUser?.user_metadata?.display_name);
    if (metaDisplay) return metaDisplay;
    const metaName = text(authMetaUser?.user_metadata?.name);
    if (metaName) return metaName;
    const userDisplay = text(user?.displayName);
    if (userDisplay) return userDisplay;
    return text(user?.email).split('@')[0] || 'Coach';
  }, [profile?.display_name, authMetaUser?.user_metadata, user?.displayName, user?.email]);

  const profilePsn = useMemo(() => {
    const resolved = resolveGamerTag({
      profile,
      user: (authMetaUser || { psn: user?.psn, user_metadata: { psn: user?.psn } }) as AuthMetaUser,
    });
    return resolved.value || '';
  }, [profile, authMetaUser, user?.psn]);

  const selectedTeamSet = useMemo(() => new Set(selectedTeamIds), [selectedTeamIds]);

  const selectedNames = useMemo(() => {
    const map = new Map(teams.map((team) => [team.id, team.name]));
    return selectedTeamIds.map((id) => map.get(id) || id);
  }, [selectedTeamIds, teams]);

  const selectedTeamRows = useMemo(() => {
    const map = new Map(teams.map((team) => [team.id, team]));
    return selectedTeamIds.map((id) => map.get(id)).filter((team): team is TeamRow => Boolean(team));
  }, [selectedTeamIds, teams]);

  const heroLogos = useMemo(() => {
    const selectedRows = teams.filter((team) => selectedTeamSet.has(team.id));
    return {
      left: selectedRows[0]?.logo_url || null,
      right: selectedRows[1]?.logo_url || null,
    };
  }, [selectedTeamSet, teams]);

  function toggleTeam(teamId: string) {
    if (submitted) return;
    setInlineError(null);

    setSelectedTeamIds((prev) => {
      if (prev.includes(teamId)) return prev.filter((id) => id !== teamId);
      if (prev.length >= 4) {
        setInlineError('You can select up to 4 preferences.');
        return prev;
      }
      return [...prev, teamId];
    });
  }

  function scrollToSection(id: string) {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  async function submitRegistration(event: React.FormEvent) {
    event.preventDefault();

    if (lockActive) {
      setInlineError('Unlocks at half-time — Swans vs Carlton (5:30pm).');
      return;
    }

    if (!user?.id) {
      navigate('/auth/sign-in', { replace: true, state: { from: '/preseason-registration' } });
      return;
    }

    if (profileLoading) {
      setInlineError('Loading your profile, please wait.');
      return;
    }

    if (!selectedTeamIds.length) {
      setInlineError('Select at least one team preference.');
      return;
    }

    const existingReg = await loadRegistrationFromTable(user.id).catch(() => null);
    if (existingReg) {
      const existingPrefs = readPrefs(existingReg).slice(0, 4);
      if (existingPrefs.length) setSelectedTeamIds(existingPrefs);
      setSubmitted(true);
      setInlineError('You are already registered for preseason.');
      return;
    }

    const freshProfile = await loadProfile(user.id).catch((error) => {
      console.error('[EG CRASH] Registration profile refresh failed', error);
      return null;
    });
    const authUserRes = await supabase.auth.getUser();
    const freshAuthUser = (authUserRes.data?.user as unknown as AuthMetaUser) || null;
    if (freshProfile) setProfile(freshProfile);
    setAuthMetaUser(freshAuthUser);

    if (!freshProfile && !profile) {
      console.warn('[PreseasonRegistration] profile still missing after refresh, continuing with auth metadata fallback', user.id);
    }
    setProfileLoadError(freshProfile ? null : 'Profile sync pending. Using account metadata for now.');

    const resolvedTag = resolveGamerTag({
      profile: freshProfile || profile,
      user: (freshAuthUser || { psn: user?.psn, user_metadata: { psn: user?.psn } }) as AuthMetaUser,
    });

    const resolvedPsn = text(resolvedTag.value);
    if (!resolvedPsn) {
      setInlineError('Add your PSN or Xbox gamertag to your account before registering.');
      return;
    }

    setInlineError(null);
    setSubmitting(true);

    try {
      const nowIso = new Date().toISOString();
      await insertRegistration({
        userId: user.id,
        selectedTeamIds,
        coachName:
          text(freshProfile?.display_name || profile?.display_name) ||
          text(freshAuthUser?.user_metadata?.display_name) ||
          text(freshAuthUser?.user_metadata?.name) ||
          signedInName,
        coachPsn: resolvedPsn,
        prefTeamNames: selectedTeamRows.map((team) => team.name),
        prefTeamSlugs: selectedTeamRows.map((team) => text(team.slug)).filter(Boolean),
      });

      const pretty = await loadPrettyRegistration(user.id);
      if (pretty) {
        setSubmittedSummary({
          coachDisplayName: text(pretty.coach_display_name) || signedInName,
          coachPsn: text(pretty.coach_psn) || resolvedPsn,
          prefTeamNames: formatPrefNames(pretty.pref_team_names),
        });
      } else {
        setSubmittedSummary({
          coachDisplayName: signedInName,
          coachPsn: resolvedPsn,
          prefTeamNames: selectedNames.join(', '),
        });
      }

      await saveProfileFlag(user.id, nowIso);
      setSubmitted(true);
    } catch (error: any) {
      console.error('[EG CRASH] PreseasonRegistration submit failed', error);
      setInlineError(String(error?.message || 'Unable to submit registration.'));
    } finally {
      setSubmitting(false);
    }
  }

  if (fatalError) {
    return (
      <div className="prPage">
        <div className="prShell">
          <section className="prErrorCard">
            <h1>Something went wrong</h1>
            <p>{fatalError}</p>
            <button type="button" className="prBtn prBtn--primary" onClick={() => window.location.reload()}>
              Reload
            </button>
          </section>
        </div>
      </div>
    );
  }

  return (
    <div className="prPage">
      <div className={`prLockable ${lockActive ? 'is-locked' : ''}`}>
        <div className="prShell">
          {submitted ? (
            <section className="prConfirmCard prConfirmCard--standalone" id="pr-confirm-card">
              <div className="prConfirmCard__icon">
                <CheckCircle2 size={22} />
              </div>
              <div className="prConfirmCard__eyebrow">AFL 26 preseason</div>
              <h2>Registration confirmed</h2>
              <p className="prConfirmCard__sub">Your preseason entry is locked in.</p>
              <div className="prConfirmCard__summary">
                <div className="prConfirmCard__row">
                  <span>Coach</span>
                  <strong>{submittedSummary?.coachDisplayName || signedInName}</strong>
                </div>
                <div className="prConfirmCard__row">
                  <span>Gamertag</span>
                  <strong>{submittedSummary?.coachPsn || profilePsn || 'TBC'}</strong>
                </div>
                <div className="prConfirmCard__row">
                  <span>Preferences</span>
                  <strong>{submittedSummary?.prefTeamNames || selectedNames.join(', ') || 'TBC'}</strong>
                </div>
              </div>
              <p className="prConfirmCard__note">{PRESEASON_FORMAT_NOTE}</p>
              <div className="prConfirmCard__state" role="status" aria-live="polite">
                Registration complete
              </div>
              <div className="prConfirmCard__actions">
                <button type="button" className="prBtn prBtn--ghost" onClick={() => scrollToSection('pr-confirm-card')}>
                  View registration
                </button>
              </div>
            </section>
          ) : (
            <>
              <RegistrationHeroCard
                className="prHeroCard"
                title="Register for AFL 26 preseason"
                subtitle="Lock in up to four preferred clubs, then confirm your place before opening bounce."
                seedNote="Your saved order becomes your official preseason entry."
                kicker="Official preseason entry"
                leftLogoUrl={heroLogos.left}
                rightLogoUrl={heroLogos.right}
                fallbackMark="EG"
                rightContent={
                  <div className="prHeroLogoTile" aria-hidden="true">
                    <img className="prHeroLogoTile__img" src={AFL26_LOGO_URL} alt="" loading="lazy" />
                  </div>
                }
                cta={
                  <div className="prHeroActions">
                    {!isLoggedIn ? (
                      <>
                        <button type="button" className="prBtn prBtn--primary" onClick={() => navigate('/auth/sign-up')}>
                          Create account
                        </button>
                        <button type="button" className="prBtn prBtn--ghost" onClick={() => navigate('/auth/sign-in')}>
                          Sign in
                        </button>
                      </>
                    ) : (
                      <button
                        type="button"
                        className="prBtn prBtn--primary"
                        disabled={lockActive}
                        onClick={() => scrollToSection('pr-form')}
                      >
                        Choose clubs
                      </button>
                    )}
                  </div>
                }
                helper={
                  <div className="prHeroHelper">
                    <span>{lockActive ? `Unlocks in ${countdown}.` : 'Registrations are live now.'}</span>
                  </div>
                }
              />

              <section className="prFormatNote" aria-label="Competition format">
                <span className="prFormatNote__label">Competition format</span>
                <span className="prFormatNote__text">{PRESEASON_FORMAT_NOTE}</span>
              </section>

              {isLoggedIn ? (
                <section className="prAccountLine" aria-label="Account status">
                  <span className="prAccountLine__eyebrow">Signed in</span>
                  <strong>{signedInName}</strong>
                  <span>{profilePsn ? `Gamertag: ${profilePsn}` : 'Add your PSN or Xbox gamertag before you confirm.'}</span>
                </section>
              ) : null}

              <section className="prFormCard" id="pr-form">
                <form onSubmit={submitRegistration} className="prForm" noValidate>
                  <div className="prFormIntro">
                    <div className="prFormIntro__copy">
                      <p className="prGridHeading">Team preferences</p>
                      <p className="prFormIntro__sub">Choose up to four clubs in order. Your saved list becomes your preseason entry.</p>
                    </div>
                  </div>

                  <TeamLogoGrid
                    teams={teams}
                    selectedTeamIds={selectedTeamIds}
                    onToggle={toggleTeam}
                    maxSelections={4}
                    disabled={submitting}
                    loading={teamsLoading}
                    emptyMessage="Team logos are syncing. Try again shortly."
                  />

                  {inlineError ? <div className="prInlineError">{inlineError}</div> : null}
                  {profileLoadError ? (
                    <button
                      type="button"
                      className="prBtn prBtn--ghost prBtn--support"
                      onClick={async () => {
                        if (!user?.id) return;
                        setProfileLoading(true);
                        const freshProfile = await loadProfile(user.id).catch(() => null);
                        const authUserRes = await supabase.auth.getUser();
                        setProfile(freshProfile);
                        setAuthMetaUser((authUserRes.data?.user as unknown as AuthMetaUser) || null);
                        if (!freshProfile) {
                          console.warn('[PreseasonRegistration] retry profile load failed, metadata fallback still active for user', user.id);
                          setProfileLoadError('Profile sync pending. Using account metadata for now.');
                        } else {
                          setProfileLoadError(null);
                        }
                        setProfileLoading(false);
                      }}
                    >
                      Retry profile sync
                    </button>
                  ) : null}
                  <button
                    type="submit"
                    className="prBtn prBtn--primary prBtn--confirm"
                    disabled={lockActive || profileLoading || teamsLoading || submitting || !selectedTeamIds.length || submitted}
                  >
                    {submitting ? 'Submitting…' : isLoggedIn ? 'Confirm preseason entry' : 'Sign in to confirm'}
                  </button>
                </form>
              </section>
            </>
          )}
        </div>
      </div>

      {lockActive ? (
        <div className="prLockOverlay" role="dialog" aria-modal="true" aria-label="Registration locked">
          <div className="prLockModal">
            <div className="prLockKicker">AFL 26 preseason</div>
            <h2 className="prLockTitle">Registrations open at 5:30pm AEDT</h2>
            <p className="prLockSub">Swans vs Carlton halftime unlock</p>
            <div className="prLockCountdown">{countdown}</div>
            <p className="prLockHint">Check back when the timer hits zero.</p>
            {!isLoggedIn ? (
              <>
                <p className="prLockHint">Create your account now so you are ready to confirm as soon as registrations unlock.</p>
                <button type="button" className="prBtn prBtn--primary" onClick={() => navigate('/auth/sign-up')}>
                  Create account
                </button>
                <button type="button" className="prBtn prBtn--ghost" onClick={() => navigate('/auth/sign-in')}>
                  Sign in
                </button>
              </>
            ) : (
              <p className="prLockHint">You’re signed in as {signedInName}</p>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}
