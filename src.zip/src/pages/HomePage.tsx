import React, { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  BarChart3,
  CalendarDays,
  ChevronRight,
  Columns3,
  Crown,
  Trophy,
  User,
  Users,
  Zap,
} from 'lucide-react';

import { useAuth } from '../state/auth/AuthProvider';
import { useLadder } from '../hooks/useLadder';
import { useNextFixtures } from '../hooks/useFixtures';
import { assetUrl } from '../lib/teamAssets';
import { resolveTeamLogoUrl } from '../lib/entityResolvers';

import '../styles/home.css';

type StatLeaderCategory = import('../lib/stats-leaders-cache').StatLeaderCategory;
type HomeCoach = import('../lib/homeRepo').HomeCoach;

const HERO_BG_URL = 'https://zohtixrgskbzosgfluni.supabase.co/storage/v1/object/public/Assets/stadium-bg-blurry.jpg';
const BGL_LOGO_URL = 'https://zohtixrgskbzosgfluni.supabase.co/storage/v1/object/public/Assets/ChatGPT%20Image%20Mar%2022,%202026,%2001_57_16%20AM.png';
const AFL26_LOGO_URL = 'https://zohtixrgskbzosgfluni.supabase.co/storage/v1/object/public/Assets/afl26-logo.png';

const teamLogoFallbackUrl = (slug?: string, name?: string, explicitLogo?: string | null) =>
  resolveTeamLogoUrl({
    logoUrl: explicitLogo || null,
    slug: slug || null,
    name: name || null,
    fallbackPath: 'elite-gaming-logo.png',
  });

function useHomepageStats() {
  const [playerData, setPlayerData] = useState<StatLeaderCategory[] | null>(null);
  const [teamData, setTeamData] = useState<StatLeaderCategory[] | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        const { fetchLeaderCategories, peekLeaderCategoriesCache } = await import('../lib/stats-leaders-cache');
        const cachedPlayers = peekLeaderCategoriesCache('players');
        const cachedTeams = peekLeaderCategoriesCache('teams');
        if (isMounted && cachedPlayers) setPlayerData(cachedPlayers);
        if (isMounted && cachedTeams) setTeamData(cachedTeams);
        if (isMounted && (cachedPlayers || cachedTeams)) setIsLoading(false);

        const [freshPlayers, freshTeams] = await Promise.all([fetchLeaderCategories('players'), fetchLeaderCategories('teams')]);
        if (!isMounted) return;
        setPlayerData(freshPlayers || []);
        setTeamData(freshTeams || []);
      } catch (error) {
        console.warn('Failed to fetch homepage stat leaders:', error);
        if (isMounted) {
          setPlayerData([]);
          setTeamData([]);
        }
      } finally {
        if (isMounted) setIsLoading(false);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, []);

  const leaders = useMemo(() => {
    const playerKeys = ['goals', 'fantasyPoints', 'disposals', 'marks'];
    const playerLeaders = playerKeys
      .map((statKey) => playerData?.find((c) => c.statKey === statKey))
      .filter(Boolean) as StatLeaderCategory[];
    const teamLeader = teamData?.find((c) => c.statKey === 'disposals' || c.statKey === 'teamDisposals');
    return teamLeader ? [...playerLeaders, teamLeader] : playerLeaders;
  }, [playerData, teamData]);

  return { leaders, isLoading };
}

function useHomeCoaches() {
  const [data, setData] = useState<HomeCoach[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        const repo = await import('../lib/homeRepo');
        const result = (await (repo as any).fetchCurrentCoaches?.()) || [];
        if (isMounted && Array.isArray(result)) setData(result);
      } catch (error) {
        console.warn('Failed to fetch current coaches:', error);
      } finally {
        if (isMounted) setIsLoading(false);
      }
    })();
    return () => {
      isMounted = false;
    };
  }, []);

  return { data, isLoading };
}

const Skeleton = ({ className }: { className?: string }) => <div className={`home-skeleton ${className || ''}`} />;

function HeroMasterCard() {
  const { user } = useAuth();
  const eliteLogo = assetUrl('elite-gaming-logo.png');

  return (
    <section className="home-hero-wrap">
      <div className="home-hero-card" style={{ backgroundImage: `url(${HERO_BG_URL})` }}>
        <div className="home-hero-card__scrim" />
        <div className="home-hero-card__glow home-hero-card__glow--gold" />
        <div className="home-hero-card__glow home-hero-card__glow--blue" />

        <div className="home-hero-card__content">
          <div className="home-brand-strip" aria-label="Elite Gaming and BGL Media">
            <div className="home-brand-strip__group">
              <div className="home-brand-mark home-brand-mark--eg">
                <span className="home-brand-mark__logo">
                  <img src={eliteLogo} alt="Elite Gaming" onError={(e) => (e.currentTarget.style.display = 'none')} />
                </span>
                <span className="home-brand-mark__text">Elite Gaming</span>
              </div>
              <span className="home-brand-strip__x" aria-hidden="true">
                x
              </span>
              <div className="home-brand-mark home-brand-mark--bgl">
                <span className="home-brand-mark__logo home-brand-mark__logo--bgl">
                  <img src={BGL_LOGO_URL} alt="BGL Media" className="home-bglLogo" />
                </span>
              </div>
            </div>
            <span className="home-hero-liveOne">
              <span className="home-hero-liveOne__dot" />
              {user ? 'Season Live' : 'Launch Live'}
            </span>
          </div>

          <div className="home-hero-titleWrap">
            <p className="home-hero-kicker">Official Elite Gaming Competition</p>
            <div className="home-afl26-logoWrap">
              <img src={AFL26_LOGO_URL} alt="AFL26" className="home-afl26-logo" />
            </div>
            <h1 className="home-hero-title">
              AFL26
              <span>Season Two</span>
            </h1>
            <p className="home-hero-sub">Premium home for fixtures, ladder and match centre.</p>
          </div>

          <div className="home-hero-actions">
            <Link to={user ? '/members' : '/auth/sign-in'} className="home-hero-btn home-hero-btn--primary">
              <span className="home-hero-btn__icon">{user ? <Crown size={16} /> : <User size={16} />}</span>
              <span>{user ? 'My Club Hub' : 'Coach Sign In'}</span>
            </Link>
            <Link to={user ? '/ladder' : '/fixtures'} className="home-hero-btn home-hero-btn--secondary">
              {user ? <Columns3 size={15} /> : <CalendarDays size={15} />}
              <span>{user ? 'View Ladder' : 'View Fixtures'}</span>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

function FeaturedMatchCard() {
  const { user } = useAuth();
  const { data, isLoading } = useNextFixtures('afl26-season-two', 1);
  const navigate = useNavigate();
  const fixture = (Array.isArray(data) ? data : (data as any)?.fixtures)?.[0];

  if (isLoading) {
    return (
      <section className="home-module home-module--feature">
        <header className="home-module__header">
          <h2>{user ? 'My Next Match' : 'Featured Match'}</h2>
          <Link to="/fixtures">
            All Fixtures
            <ChevronRight size={15} />
          </Link>
        </header>
        <Skeleton className="home-featured-skeleton" />
      </section>
    );
  }

  if (!fixture) {
    return (
      <section className="home-module home-module--feature">
        <header className="home-module__header">
          <h2>{user ? 'My Next Match' : 'Featured Match'}</h2>
          <Link to="/fixtures">
            All Fixtures
            <ChevronRight size={15} />
          </Link>
        </header>
        <div className="home-empty">Season fixtures will appear shortly.</div>
      </section>
    );
  }

  const homeName = fixture.home_team_name || fixture.home_team_short_name || fixture.home_team_slug?.replace(/-/g, ' ') || 'TBD';
  const awayName = fixture.away_team_name || fixture.away_team_short_name || fixture.away_team_slug?.replace(/-/g, ' ') || 'TBD';
  const homeLogo = teamLogoFallbackUrl(fixture.home_team_slug, homeName, fixture.home_team_logo_url);
  const awayLogo = teamLogoFallbackUrl(fixture.away_team_slug, awayName, fixture.away_team_logo_url);

  let dateText = 'Time TBA';
  if (fixture.start_time) {
    const d = new Date(fixture.start_time);
    if (!isNaN(d.getTime())) {
      dateText = d.toLocaleDateString('en-AU', {
        weekday: 'short',
        day: 'numeric',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit',
      });
    }
  }

  return (
    <section className="home-module home-module--feature">
      <header className="home-module__header">
        <h2>{user ? 'My Next Match' : 'Featured Match'}</h2>
        <Link to="/fixtures">
          All Fixtures
          <ChevronRight size={15} />
        </Link>
      </header>

      <button type="button" className="home-feature-card" onClick={() => navigate(`/match-centre/afl26-season-two/${fixture.round}/${fixture.id}`)}>
        <div className="home-feature-card__meta">
          <span className="home-feature-card__round">Round {fixture.round || '-'}</span>
          <span className="home-feature-card__date">{fixture.status === 'COMPLETED' ? 'Full Time' : dateText}</span>
        </div>

        <div className="home-feature-card__main">
          <div className="home-feature-card__team">
            <span className="home-feature-card__logo">
              <img src={homeLogo} alt={homeName} onError={(e) => (e.currentTarget.style.display = 'none')} />
            </span>
            <span>{homeName}</span>
          </div>
          <div className="home-feature-card__vs">vs</div>
          <div className="home-feature-card__team">
            <span className="home-feature-card__logo">
              <img src={awayLogo} alt={awayName} onError={(e) => (e.currentTarget.style.display = 'none')} />
            </span>
            <span>{awayName}</span>
          </div>
        </div>

        <div className="home-feature-card__cta">
          <span>Enter Match Centre</span>
          <ArrowRight size={15} />
        </div>
      </button>
    </section>
  );
}

function LeadersPreview() {
  const navigate = useNavigate();
  const { leaders, isLoading } = useHomepageStats();

  return (
    <section className="home-module home-module--leaders">
      <header className="home-module__header">
        <h2>Season Leaders</h2>
        <Link to="/stats3">
          Stats Hub
          <ChevronRight size={15} />
        </Link>
      </header>

      {isLoading && leaders.length === 0 ? (
        <div className="home-leaders-rail">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="home-leader-card">
              <Skeleton className="home-leader-skeleton__top" />
              <Skeleton className="home-leader-skeleton__value" />
              <div className="home-leader-divider" />
              <div className="home-leader-row">
                <Skeleton className="home-leader-skeleton__avatar" />
                <div className="home-leader-skeleton__meta">
                  <Skeleton className="home-leader-skeleton__line" />
                  <Skeleton className="home-leader-skeleton__line short" />
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : leaders.length > 0 ? (
        <div className="home-leaders-rail">
          {leaders.map((category) => {
            if (!category?.top) return null;
            const top = category.top;
            const isTeamLeader = category.mode === 'teams';
            return (
              <button key={category.statKey} type="button" className="home-leader-card" onClick={() => navigate('/stats3')}>
                <div className="home-leader-top">
                  <span className="home-leader-label">{category.label}</span>
                  <span className="home-leader-chip">{isTeamLeader ? 'Top Team' : 'Top Player'}</span>
                </div>
                <div className="home-leader-value">{top.valueTotal}</div>
                <div className="home-leader-divider" />
                <div className="home-leader-row">
                  <div className="home-leader-avatar">
                    {top.photoUrl ? <img src={top.photoUrl} alt={top.name} /> : <User size={16} />}
                  </div>
                  <div className="home-leader-meta">
                    <p>{top.name}</p>
                    <span>{top.teamName || 'Season Leader'}</span>
                  </div>
                  <strong>#1</strong>
                </div>
              </button>
            );
          })}
        </div>
      ) : (
        <div className="home-empty">Leaderboards will appear once stats are submitted.</div>
      )}
    </section>
  );
}

function LadderSnapshot() {
  const { data, isLoading } = useLadder('afl26-season-two');
  const ladder = useMemo(() => (Array.isArray(data) ? data.slice(0, 8) : []), [data]);

  return (
    <section className="home-module home-module--ladder">
      <header className="home-module__header">
        <h2>Ladder Snapshot</h2>
        <Link to="/ladder">
          Full Ladder
          <ChevronRight size={15} />
        </Link>
      </header>

      <div className="home-ladder-card">
        {isLoading ? (
          <div className="home-ladder-skeleton">
            {Array.from({ length: 8 }).map((_, i) => (
              <Skeleton key={i} className="home-ladder-skeleton__row" />
            ))}
          </div>
        ) : ladder.length > 0 ? (
          <div className="home-ladder-tableWrap">
            <table className="home-ladder-table">
              <thead>
                <tr>
                  <th>Pos</th>
                  <th>Club</th>
                  <th>P</th>
                  <th>Pts</th>
                  <th>%</th>
                </tr>
              </thead>
              <tbody>
                {ladder.map((team: any, index: number) => {
                  const logo = teamLogoFallbackUrl(team.team_slug, team.team_name, team.team_logo_url);
                  const rank = Number(team.position || index + 1);
                  return (
                    <tr key={team.team_slug || `${team.team_name}-${index}`} className={index === 3 ? 'is-top-four-cut' : ''}>
                      <td>
                        <span className={`home-ladder-rank ${rank === 1 ? 'is-first' : rank <= 4 ? 'is-top-four' : ''}`}>{rank}</span>
                      </td>
                      <td className="home-ladder-club">
                        <span className="home-ladder-logoWrap">
                          <img src={logo} alt={team.team_name || 'Team'} onError={(e) => (e.currentTarget.style.display = 'none')} />
                        </span>
                        <span className="home-ladder-name">{team.team_name || 'Team'}</span>
                      </td>
                      <td>{team.played || 0}</td>
                      <td className="home-ladder-points">{team.points || 0}</td>
                      <td>{Number(team.percentage || 0).toFixed(1)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="home-empty">Ladder data will appear after Round 1.</div>
        )}
      </div>
    </section>
  );
}

function CommunityPreview() {
  const { user } = useAuth();
  const { data: coaches, isLoading } = useHomeCoaches();
  const visible = useMemo(() => coaches.slice(0, 8), [coaches]);

  return (
    <section className="home-module home-module--community">
      <header className="home-module__header">
        <h2>{user ? 'Coach Community' : 'Coaches & Clubs'}</h2>
        <Link to={user ? '/members' : '/auth/sign-in'}>
          {user ? 'Open Hub' : 'Join Hub'}
          <ChevronRight size={15} />
        </Link>
      </header>

      {isLoading ? (
        <div className="home-community-rail">
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="home-coach-skeleton" />
          ))}
        </div>
      ) : visible.length > 0 ? (
        <>
          <div className="home-community-rail">
            {visible.map((coach) => (
              <article key={`${coach.user_id}-${coach.team_id}`} className="home-community-card">
                <div className="home-community-card__logo">
                  {coach.team_logo_url ? <img src={coach.team_logo_url} alt={coach.team_name || 'Team'} /> : <Users size={16} />}
                </div>
                <div className="home-community-card__meta">
                  <strong>{coach.display_name || coach.psn || 'Coach'}</strong>
                  <span>{coach.team_name || 'Team assigned'}</span>
                </div>
              </article>
            ))}
          </div>
          <Link to={user ? '/members' : '/auth/sign-in'} className="home-community-cta">
            <Users size={15} />
            <span>{user ? 'Open Member Hub' : 'Sign in to open Member Hub'}</span>
          </Link>
        </>
      ) : (
        <div className="home-empty">Coach and club profiles will appear as teams lock in.</div>
      )}
    </section>
  );
}

function ExploreSeasonLinks() {
  const { user } = useAuth();
  const links = [
    { to: '/fixtures', label: 'Fixtures', icon: CalendarDays },
    { to: '/ladder', label: 'Ladder', icon: Trophy },
    { to: '/stats3', label: 'Stats', icon: BarChart3 },
    { to: '/match-centre', label: 'Match Centre', icon: Zap },
    { to: user ? '/members' : '/auth/sign-in', label: user ? 'Members' : 'Sign In', icon: User },
  ];

  return (
    <section className="home-module home-module--explore">
      <header className="home-module__header">
        <h2>{user ? 'Inside Season Two' : 'Explore AFL26'}</h2>
      </header>
      <div className="home-explore-grid">
        {links.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.to} to={item.to} className="home-explore-link">
              <span className="home-explore-link__icon">
                <Icon size={14} />
              </span>
              <span>{item.label}</span>
              <ChevronRight size={14} />
            </Link>
          );
        })}
      </div>
    </section>
  );
}

export default function HomePage() {
  return (
    <div className="home-page">
      <main className="home-main">
        <HeroMasterCard />
        <FeaturedMatchCard />
        <LadderSnapshot />
        <LeadersPreview />
        <CommunityPreview />
        <ExploreSeasonLinks />
      </main>
    </div>
  );
}